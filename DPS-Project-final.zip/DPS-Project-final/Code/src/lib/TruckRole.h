#ifndef TRUCKROLE_H
#define TRUCKROLE_H

#pragma once

enum truckRole {
    NOT_SET,
    LEADER,
    FOLLOWER
};

#endif
