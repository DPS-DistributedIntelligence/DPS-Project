#ifndef SURROUNDINGTRUCK_H
#define SURROUNDINGTRUCK_H

typedef struct SurroundingTruck{
    int x_location = -1;
    int id = -1;
}SurroundingTruck;

#endif
