#ifndef LOCATION_H
#define LOCATION_H

typedef struct Location{
    int x = -1;
    int y = -1;
}Location;

#endif
