#ifndef LIB
#define LIB

#pragma once
#include "TruckRole.h"
#include "Movement.h"
#include "Event.h"

#endif