# DPS-DistributedIntelligence

Group project.

## Subjects to Cover
- [x] Create System Architecture.
- [x] Create Activity Diagram.
- [x] Create Sequence Diagram.
- [x] Set State Machine.
  > [x] State Machine Leader.
  > [x] State Machine Follower.
- [x] Set Communication Protocol.
  > TCP/IP
- [ ] Create Class Diagram
- [x] Set Lenguage to be used
  > C++
  > > Concurrency
  > > 
  > > > OpenMP
  > > > 
  > > Parallelism
  > > 
  > > > CUDA
- [ ] Simulation model
  > refer [our diagram](https://drive.google.com/file/d/1gNeNTzplQIQAvc6RsRsR8JvbSZtf4c4z/view)
  > [!Note]
  > Some suggestions are added 

> [!Note]
> Add notes important for the project

> [!IMPORTANT]
> Instructions and other things

   
## Authors
> Name: Luis Fernando Rodriguez Gutierrez.
> 
> Matriculation Number: 7219085.

> Name: Leander Hackmann
> 
> Matriculation Number: 7217912.

> Name: Sheikh Muhammad Adib
>
> Matriculation Number: 7219310
>

> Name: Mykyta Konakh
>
> Matriculation Number: 7219011

> Name: Aditya Kumar
>
> Matriculation Number: 7219675

## Leander

> [!Note]
> blah labh
> blah

> Workload:
> - [ ] Task 1
> > - [x] Task 1.1
> > - [ ] Task 1.2 

## Mykyta

> [!Note]
> blah labh
> blah

> Workload:
> - [ ] Task 1
> > - [x] Task 1.1
> > - [ ] Task 1.2 

## Sheikh

> [!Note]
> blah labh
> blah

> Workload:
> - [ ] Task 1
> > - [x] Task 1.1
> > - [ ] Task 1.2

## Luis

> [!Note]
> blah labh
> blah

> Workload:
> - [ ] Task 1
> > - [x] Task 1.1
> > - [ ] Task 1.2

## Aditya

> [!Note]
> blah labh
> blah

> Workload:
> - [ ] Task 1
> > - [x] Task 1.1
> > - [ ] Task 1.2 
